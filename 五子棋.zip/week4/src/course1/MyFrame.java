package course1;

import javax.swing.*;
import java.awt.*;

public class MyFrame extends JFrame {
    private ShapeList<Coordinate> shapelist;

    public MyFrame(String title){
        super(title);
    }

    public void setShapelist(ShapeList<Coordinate> shapelist) {
        this.shapelist = shapelist;
    }

    public void paint(Graphics g)
    {
        for(int i=2;i<15;i++)
            for(int j=2;j<15;j++)
            {
                g.drawRect(50*i,50*j,50,50);
                Coordinate coordinate = new Coordinate(50*i,50*j);
                Coordinate coordinate1 = new Coordinate(50*i+50,50*j+50);
                shapelist.add(coordinate);
                shapelist.add(coordinate1);
            }
    }
}
