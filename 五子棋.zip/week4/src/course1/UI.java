package course1;

import javax.swing.*;
import java.awt.*;

public class UI {
    public void show(){
        ShapeList<Coordinate> shapelist = new ShapeList<>();
        MyFrame frame = new MyFrame("五子棋");
        frame.setShapelist(shapelist);
        frame.setSize(900,1200);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);

        Graphics g = frame.getGraphics();
        for(int i=0;i<15;i++)
            for(int j=0;j<15;j++)
            {
                g.drawRect(50*i,50*j,50,50);
            }
        GameMouse mouse = new GameMouse(g);
        mouse.setShapelist(shapelist);
        frame.addMouseListener(mouse);
        mouse.drawChessBoard();
    }

    public static void main(String[] args) {
        UI ui = new UI();
        ui.show();
    }
}
