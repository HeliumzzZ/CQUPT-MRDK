package course1;

import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;

public class GameMouse extends MouseAdapter {
    private Graphics g;
    private ShapeList<Coordinate> shapelist;
    public  int flag=0;

    public void setShapelist(ShapeList<Coordinate> shapelist) {
        this.shapelist = shapelist;
    }

    public int minnumIndex(int[] arr) {
        int min = 0;
        for (int i = 0; i < arr.length; i++) {
            if (arr[min] > arr[i]) {
                min = i;
            }

        }
        return min;
    }

    public GameMouse(Graphics g) {
        this.g = g;
    }

    public void drawChessBoard() {
        for (int i = 0; i < 15; i++)
            for (int j = 0; j < 15; j++) {
                g.drawRect(50 * i, 50 * j, 50, 50);
            }
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        int x = e.getX();
        int y = e.getY();
        int[] array = new int[shapelist.size()];
        for (int i = 0; i < shapelist.size(); i++) {
            Coordinate coord = shapelist.get(i);
            int dt = (int) Math.pow(x - coord.x, 2) + (int) Math.pow(y - coord.y, 2);
            array[i] = dt;
        }
        if(flag==0)
        {
            g.setColor(Color.black);
            g.fillOval(shapelist.get(minnumIndex(array)).x-25,shapelist.get(minnumIndex(array)).y-25,50,50);

            flag =1;

        }else {
            g.setColor(Color.white);

            g.fillOval(shapelist.get(minnumIndex(array)).x-25,shapelist.get(minnumIndex(array)).y-25,50,50);

            flag = 0;
        }



    }

    @Override
    public void mousePressed(MouseEvent e) {

    }

    @Override
    public void mouseReleased(MouseEvent e) {

    }

    @Override
    public void mouseEntered(MouseEvent e) {

    }

    @Override
    public void mouseExited(MouseEvent e) {

    }
}
