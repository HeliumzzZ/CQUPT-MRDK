package course1;

import java.util.Arrays;

public class ShapeList<T>{

    private int size;
    private Object[] arr = new Object[0];
    public void add(T element) {
//        Object[] newArr = new Object[arr.length+1];
//        for (int i = 0; i < arr.length; i++) {
//            newArr[i] = arr[i];
//        }
//        newArr[arr.length] = element;
//        arr = newArr;
        int i = arr.length;
        arr = Arrays.copyOf(arr,arr.length+1);
        arr[i] = element;

        size++;
    }

    public void removeByIndex(int index) {
        if (index < 0 || index >= size) {
            throw new IndexOutOfBoundsException("下标越界");
        }
        for (int i = index; i < size - 1; i++) {
            arr[i] = arr[index + 1];
        }
        size--;
    }

    public String removeByObject(T shape) {
        for (int i = 0; i < size; i++) {
            if(shape==arr[i]){
                for (int j=i;j<size-1;j++) {
                    arr[j] = arr[j + 1];
                }
                size--;
                return "删除成功";
            }
        }
        return "未找到该元素";
    }

    public T get(int index) {
        if (index < 0 || index >= size) {
            throw new IndexOutOfBoundsException("下标越界!");
        }
        return (T) arr[index];
    }

    public int size() {
        return size;
    }


}
