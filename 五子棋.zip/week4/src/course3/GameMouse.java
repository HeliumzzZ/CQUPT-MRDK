package course3;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JLabel;


//事件处理类
public class GameMouse extends MouseAdapter implements ActionListener {
	//画笔对象
	private Graphics g;
	private GameParam param;
	private int x,y;
	private MyPanel board;
	private JLabel welcome, notice;

	//构造方法初始化属性
	public GameMouse(){}

	public GameMouse(Graphics g){
		this.g = g;
	}

	//设置
	public void setGraphic(Graphics g) {
		this.g = g;
	}
	public void setBoard(MyPanel board) {
		this.board = board;
	}

	public void setParam(GameParam param) {
		this.param = param;
	}

	public void setLabel(JLabel welcome, JLabel notice) {
		this.welcome = welcome;
		this.notice = notice;
	}
	/*
	 * 以下是触发事件监听
	 */

	//按下
	public void mousePressed(MouseEvent e) {
		x = e.getX()-12;
		y = e.getY()-20;
	}

	//松开
	public void mouseReleased(MouseEvent e) {
		int x0 = e.getX()-12;
		int y0 = e.getY()-20;
		if(Math.abs(x-x0)<10 && Math.abs(y-y0)<10) {
//        	System.out.println(x+" "+y);
			int length = GameParam.length;
			x = ( x%length<length/2? x-x%length:x-x%length+length);
			y = ( y%length<length/2? y-y%length:y-y%length+length);
//        	System.out.println(x+" "+y);
			//绘制棋子
			if(param.putPiece(g, x/GameParam.length, y/GameParam.length)) {
				notice.setText("轮到"+param.getturnName()+"  "+param.getModename());
				if(param.checkWin(x/GameParam.length,y/GameParam.length))
					param.endGame(GameParam.WIN);
				if(1==param.getMode()) {
					int AIseat[] = param.doAI(param.getTurn(), param.getDifficulty());
					if(param.putPiece(g, AIseat[0]+1, AIseat[1]+1)) {
						notice.setText("轮到"+param.getturnName()+"  "+param.getModename());
						if(param.checkWin(AIseat[0]+1, AIseat[1]+1))
							param.endGame(GameParam.LOSE);
					}
				}
			}
			if(param.getRound()==169)
				param.endGame(GameParam.DRAW);
//        		if(param.putPiece(g,x/GameParam.length-1,y/GameParam.length-1))
//        			if(param.checkWin(x/GameParam.length-1,y/GameParam.length-1))
//        				param.win();
		}
	}


	//按钮
	public void actionPerformed(ActionEvent e) {
		String name = e.getActionCommand();
		switch(name) {
			case "开始游戏":
				if(!param.check()) {
					setLabel(false);
					param.start();
					notice.setText("轮到"+""+param.getturnName()+"  "+param.getModename());
					board.paint(g);
				}
				break;
			case "重新开始":
				if(0==param.getIndex())
					break;
//			System.out.println(param.getRound());
				setLabel(false);
				param.start();
				notice.setText("轮到"+""+param.getturnName()+"  "+param.getModename());
				board.paint(g);
				break;
			case "悔棋":
				if(!param.check())
					break;
				param.withdraw();
				board.paint(g);
				break;
			case "认输":
				if(!param.check())
					break;
				param.endGame(GameParam.LOSE);
//			board.paint(g);
				break;
			case "切换模式":
				if(!param.check())
					break;
				if(1==param.getMode()) {
					param.changeMode((byte)0);
					param.setHashMap();
				}
				else if(0==param.getMode())
					param.changeMode((byte)1);
				notice.setText("轮到"+""+param.getturnName()+"  "+param.getModename());
				break;
			case "复盘":
				if(!param.check())
					break;
//			param.endGame(GameParam.WIN);
				break;
			case "非常简单":
				param.setDifficulty(-1);
				break;
			case "简单":
				param.setDifficulty(0);
				break;
			case "一般":
				param.setDifficulty(1);
				break;
			default:
				break;
		}
	}


	//图片清屏
	public void setLabel(boolean b) {
		if(null!=welcome)
			welcome.setVisible(b);
	}


}