package course3;

import java.awt.Color;
import java.awt.Graphics;

import javax.swing.JPanel;

public class MyPanel extends JPanel {
	
	private static final long serialVersionUID = 1L;
	private GameParam param;
//	public void setmouse(int[] location) {
//		this.location = location;
//	}
	
//	public void setRound(int round) {
//		this.round = round;
//	}
	public void setParam(GameParam param) {
		this.param = param;
	}
	public void paintBoard(Graphics g) {
		if(!param.check())
			return;
		g.setColor(Color.BLACK);
    	int x0=7,y0=14,length=40;
    	g.drawLine(x0, y0, x0+570, y0);
    	g.drawLine(x0+570, y0, x0+570, y0+570);
    	g.drawLine(x0+570, y0+570, x0, y0+570);
    	g.drawLine(x0, y0+570, x0, y0);
    	for(int i=0; i<=16; i++) {
    		g.drawLine(x0+5+i*length, y0+5, x0+5+i*length, y0+5+560);
    		g.drawLine(x0+5, y0+5+i*length, x0+5+560, y0+5+i*length);
    	}
    	g.fillOval(x0+5+7*length-8, y0+5+7*length-8, 16, 16);
    	g.fillOval(x0+5+4*length-6, y0+5+4*length-6, 12, 12);
    	g.fillOval(x0+5+10*length-6, y0+5+4*length-6, 12, 12);
    	g.fillOval(x0+5+4*length-6, y0+5+10*length-6, 12, 12);
    	g.fillOval(x0+5+10*length-6, y0+5+10*length-6, 12, 12);
    }
	
	
	public void paint(Graphics g) {
		super.paint(g);
		param.drawBoard(g);
		param.drawPieces(g);
	}
	

}
