package course3;


//import java.awt.Color;
//import java.awt.Graphics;

import javax.swing.JFrame;

public class MyFrame extends JFrame{

	private static final long serialVersionUID = 1L;
//	private GameParam param;
//	private Graphics g;
	
	public MyFrame(String name) {
		super(name);
	}
//	public void setparam(GameParam param) {
//		this.param = param;
//	}
//	public void setGraphics(Graphics g) {
//		this.g = g;
//	}
	
	public void setVisible(boolean b) {
		super.setVisible(b);
		try {
			Thread.sleep(50);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
//		param.drawBoard(g);
	}
}
