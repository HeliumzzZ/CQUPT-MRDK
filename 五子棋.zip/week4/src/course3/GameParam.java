package course3;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.util.ArrayList;
import java.util.HashMap;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class GameParam {
	
	HashMap<String, Integer> hm = new HashMap<>();//�������Ȩֵ
	private byte mode = 1;
	private String modename = "�˻���ս";
	private boolean flag = false;
	private int index = 0;
	private int round = 1;
	private int difficulty = -1;
	private byte seat[][] = new byte[NUM][NUM];
	private ArrayList<Integer[]> Lastlist = new ArrayList<Integer[]>();
	public static int x0=7,y0=14,length=40;
	public static int BLACK = 1;
    public static int WHITE = 2;
    public static int NUM = 15;
    public static int LINE = 15;
    public static int SIZE = 34;
    public static byte WIN = 1;
    public static byte DRAW = 0;
    public static byte LOSE = -1;
    
    //��ʼ������
    public void start() {
    	clearall();
    	flag = true;
    	setHashMap();
    }
	public int clearall() {
		clearRound();
		clearSeat();
		index++;
		return index;
	}

	//��Ϸģʽ
	public byte getMode() {
    	return mode;
    }
	public String getModename() {
    	return modename;
    }
	//ģʽ�л�
	public void changeMode(byte change) {
    	if(1==change) {
    		mode = 1;
    		modename = "�˻���ս";
    	}
    	else if(0==change) {
    		mode = 0;
    		modename = "��Ҷ�ս";
    	}
//    	flag = false;
    }
	//�����Ѷ�
	public void setDifficulty(int difficulty) {
		this.difficulty = difficulty;
	}
	public int getDifficulty() {
		return difficulty;
	}
	
	//��Ϸ����
	public void endGame(byte result) {
    	if(!check()) {
    		return;
    	}
    	//�����½���
		JFrame jf2 = new JFrame();
		jf2.setSize(540,450);
		jf2.setVisible(true);
		FlowLayout flow = new FlowLayout();
		jf2.setLayout(flow);
		//����
		jf2.setLocationRelativeTo(null);
		//ͼƬ
		ImageIcon image2 = null;
		JLabel answer = null;
		if(-1==result) {
			image2 = new ImageIcon("2233-lose.jpg");
			answer = new JLabel("�����ˣ�");
		}
		else if(0==result) {
			image2 = new ImageIcon("2233-win.jpg");
			answer = new JLabel("ƽ�֣�");
		}
		else if(1==result) {
			image2 = new ImageIcon("2233-win.jpg");
			if(1==mode) 
				answer = new JLabel("��Ӯ�ˣ�");
			else if((0==mode) && (round%2==0)) {
				answer = new JLabel("����Ӯ�ˣ�");
			}
			else if((0==mode) && (round%2==1)) {
				answer = new JLabel("����Ӯ�ˣ�");
			}
		}
		JLabel im2 = new JLabel(image2);
		jf2.add(im2);
		//��ʾ
		jf2.add(answer);
		clearall();
		flag = false;
	}

	
	
	//�����Ϸ�Ƿ�ʼ
	public boolean check() {
		return flag;
	}
    public int getIndex() {
    	return index;
    }
	
	//�غ������
	public int getRound() {
		return round;
	}
	public void addRound() {
		round++;
	}
	public void minusRound() {
		if(0==round)
			return;
		round--;
	}
	public void clearRound() {
		round = 1;
	}
	
	//����״̬���
	public int getTurn() {
		if(1==round%2)
			return BLACK;
		else
			return WHITE;
	}
	public String getturnName() {
		if(1==round%2)
			return "����";
		else
			return "����";
	}
	public byte[][] getSeat() {
		return seat;
	}
	public byte getSeat(int x, int y) {
		return seat[x][y];
	}
	public void setSeat(int x,int y,byte color) {
		seat[x][y] = color;
	}
	public void printSeat() {
		for(int i=0;i<NUM;i++) {
			for(int j=0;j<NUM;j++) 
				System.out.printf("%3d",seat[j][i]);
			System.out.println();
		}
	}
	public void clearSeat() {
		for(int i=0;i<NUM;i++) 
			for(int j=0;j<NUM;j++) 
				seat[i][j] = (byte)0;
	}
	//���塢�������
	public void addPieces(Integer[] location) {
		Lastlist.add(location);
	}
	//����
	public void withdraw() {
		if(Lastlist.size()-1<0)
			return;
		Integer[] last = Lastlist.remove(Lastlist.size()-1);
		seat[last[0]][last[1]] = 0;
		if(round>1)
			round--;
		if(1==mode) {
			if(Lastlist.size()-1<0)
				return;
			Integer[] last2 = Lastlist.remove(Lastlist.size()-1);
			seat[last2[0]][last2[1]] = 0;
			if(round>1)
				round--;
		}
	}
	
	//��������
	public void drawBoard(Graphics g) {
		if(!check())
			return;
		g.setColor(Color.BLACK);
    	g.drawLine(x0, y0, x0+length*(NUM+1)+10, y0);
    	g.drawLine(x0+length*(NUM+1)+10, y0, x0+length*(NUM+1)+10, y0+length*(NUM+1)+10);
    	g.drawLine(x0+length*(NUM+1)+10, y0+length*(NUM+1)+10, x0, y0+length*(NUM+1)+10);
    	g.drawLine(x0, y0+length*(NUM+1)+10, x0, y0);
    	for(int i=0; i<=16; i++) {
    		g.drawLine(x0+5+i*length, y0+5, x0+5+i*length, y0+5+length*(NUM+1));
    		g.drawLine(x0+5, y0+5+i*length, x0+5+length*(NUM+1), y0+5+i*length);
    	}
    	g.fillOval(x0+5+8*length-8, y0+5+8*length-8, 16, 16);
    	g.fillOval(x0+5+4*length-6, y0+5+4*length-6, 12, 12);
    	g.fillOval(x0+5+12*length-6, y0+5+4*length-6, 12, 12);
    	g.fillOval(x0+5+4*length-6, y0+5+12*length-6, 12, 12);
    	g.fillOval(x0+5+12*length-6, y0+5+12*length-6, 12, 12);
    }
	
	//����
	public boolean putPiece(Graphics g, int X, int Y) {
		if(!check())
			return false;
		if(1>X||GameParam.NUM<X||1>Y||GameParam.NUM<Y)
			return false;
    	if(0!=getSeat(X-1, Y-1)) {
    		return false;
    	}
    	if(GameParam.BLACK==round%2){
        	for(int i=0;i<82;i++) {
        		Color c = new Color(3*i,3*i,3*i);
            	g.setColor(c);
            	int x1 = x0+5+X*length-SIZE/2;
            	int y1 = y0+5+Y*length-SIZE/2;
            	g.fillOval(x1+i/14*2,y1+i/14*2,SIZE-i*10/27,SIZE-i*10/27);
            }
        	setSeat(X-1, Y-1, (byte)1);
        }
        else {
        	for(int i=0;i<82;i++) {
            	Color c = new Color(173+i,173+i,173+i);
            	g.setColor(c);
            	int x2 = x0+5+X*length-SIZE/2;
            	int y2 = y0+5+Y*length-SIZE/2;
            	g.fillOval(x2+i/15*2,y2+i/15*2,SIZE+1-i/3,SIZE+1-i/3);
            }
        	setSeat(X-1, Y-1, (byte)2);
        }
    	Integer[] piece = {X-1,Y-1};
    	addPieces(piece);
    	round++;
		return true;
	}
	
	//�ع�����
	public void drawPieces(Graphics g) {
		for(int i=0;i<NUM;i++) {
			for(int j=0;j<NUM;j++) {
				if(BLACK==seat[i][j]) {
					for(int k=0;k<82;k++) {
		        		Color c = new Color(3*k,3*k,3*k);
		            	g.setColor(c);
		            	int x1 = x0+5+(1+i)*length-17;
		            	int y1 = y0+5+(1+j)*length-17;
		            	g.fillOval(x1+k/14*2,y1+k/14*2,SIZE-k*10/27,SIZE-k*10/27);
		            }
				}
				else if(WHITE==seat[i][j]) {
					for(int k=0;k<82;k++) {
		            	Color c = new Color(173+k,173+k,173+k);
		            	g.setColor(c);
		            	int x2 = x0+5+(1+i)*length-17;
		            	int y2 = y0+5+(1+j)*length-17;
		            	g.fillOval(x2+k/15*2,y2+k/15*2,SIZE+1-k/3,SIZE+1-k/3);
		            }
				}	
			}
		}
	}
	
	//����Ƿ�ʤ��
	public boolean checkWin(int x, int y) {
		String[] SearchArr = new String[4];
		SearchArr = search(SearchArr, seat, x-1, y-1);
		String Evel = SearchArr[0];     	//��¼ˮƽ����
		String Vertical = SearchArr[1];		//��¼��ֱ����
		String LeftCross = SearchArr[2];	//��¼���ϡ������·���
		String RightCross = SearchArr[3];	//��¼���ϡ������·���
		if(Evel.contains("11111") || Evel.contains("22222"))
			return true;
		if(Vertical.contains("11111") || Vertical.contains("22222"))
			return true;
		if(LeftCross.contains("11111") || LeftCross.contains("22222"))
			return true;
		if(RightCross.contains("11111") || RightCross.contains("22222"))
			return true;
		return false;
		}
	
	//����������Χ����ȡ��������
	public String[] search(String[] SearchArr, byte[][] seat, int X, int Y) {
		String Evel = "";     	
		String Vertical = "";	
		String LeftCross = "";	
		String RightCross = "";	
		byte color = 0;
		int i,j;
		color = seat[X][Y];
		//ˮƽ����
		Evel += seat[X][Y];					//���浱ǰ����
		for(i=X-1,j=Y;i>=0;i--) {
			if(0 == seat[i][j]) {			//�ж������Ƿ�����
				break;
			}else if(seat[i][j] != color) {	//�ж������Ƿ���ɫ
				Evel = seat[i][j] + Evel;
				break;
			}else if(seat[i][j] == color) {	
				Evel = seat[i][j] + Evel;
			}
		}
		for(i=X+1,j=Y;i<NUM;i++) {
			if(0 == seat[i][j]) {	
				break;
			}else if(seat[i][j] != color) {	
				Evel +=  seat[i][j];
				break;
			}else if(seat[i][j] == color) {	
				Evel +=  seat[i][j];
			}
		}
		
		//��ֱ����
		Vertical += seat[X][Y];
		for(i=X,j=Y-1;j>=0;j--) {
			if(0 == seat[i][j]) {			//�ж��Ƿ�����
				break;
			}else if(seat[i][j] != color) {	//�ж��Ƿ�����ɫ����
				Vertical = seat[i][j] + Vertical;
				break;
			}else if(seat[i][j] == color) {	
				Vertical = seat[i][j] + Vertical;
			}
		}
		for(i=X,j=Y+1;j<NUM;j++) {
			if(0 == seat[i][j]) {			
				break;
			}else if(seat[i][j] != color) {	
				Vertical +=  seat[i][j];
				break;
			}else if(seat[i][j] == color) {	
				Vertical +=  seat[i][j];
			}
		}

		//���ϡ������·���
		LeftCross += seat[X][Y];
		for(i=X-1, j=Y-1; i>=0 && j>=0; i--, j--) {
			if(0 == seat[i][j]) {			//�ж��Ƿ�����
				break;
			}else if(seat[i][j] != color) {	//�ж��Ƿ�����ɫ����
				LeftCross = seat[i][j] + LeftCross;
				break;
			}else if(seat[i][j] == color) {	
				LeftCross = seat[i][j] + LeftCross;
			}
		}
		for(i=X+1, j=Y+1; i<NUM && j<NUM; i++, j++) {
			if(0 == seat[i][j]) {			
				break;
			}else if(seat[i][j] != color) {	
				LeftCross +=  seat[i][j];
				break;
			}else if(seat[i][j] == color) {	
				LeftCross +=  seat[i][j];
			}
		}

		//���ϡ������·���
		RightCross += seat[X][Y];
		for(i=X+1, j=Y-1; i<NUM && j>=0; i++, j--) {
			if(0 == seat[i][j]) {			//�ж��Ƿ�����
				break;
			}else if(seat[i][j] != color) {	//�ж��Ƿ�����ɫ����
				RightCross = seat[i][j] + RightCross;
				break;
			}else if(seat[i][j] == color) {	
				RightCross = seat[i][j] + RightCross;
			}
		}
		for(i=X-1, j=Y+1; i>=0 && j<NUM; i--, j++) {
			if(0 == seat[i][j]) {			
				break;
			}else if(seat[i][j] != color) {	
				RightCross +=  seat[i][j];
				break;
			}else if(seat[i][j] == color) {	
				RightCross +=  seat[i][j];
			}
		}
		SearchArr[0] = Evel;     	
		SearchArr[1] = Vertical;	
		SearchArr[2] = LeftCross;	
		SearchArr[3] = RightCross;	
//		System.out.println(Evel+" "+Vertical+" "+LeftCross+" "+RightCross);
		return SearchArr;
	}
	
	//����HashMap������Ȩֵ���Ų��ļ�ֵ��
	public void setHashMap() {
		//�º���
        hm.put("1", 0);
        hm.put("2", 0);
        hm.put("12",2);
        hm.put("21", 2);
        hm.put("212",1);
        hm.put("121", 5);
        
        hm.put("11",20);
        hm.put("22", 20);
        hm.put("112", 10);
        hm.put("211", 10);
        hm.put("122", 10);
        hm.put("221", 10);
        hm.put("2112", 5);
        hm.put("1221", 5);
        
        hm.put("111",200);
        hm.put("222", 200);
        hm.put("1112",12);
        hm.put("2221", 12);
        hm.put("2111",12);
        hm.put("1222", 12);
        hm.put("21112",5);
        hm.put("12221", 5);
        
        hm.put("1111",15000);
        hm.put("2222", 15000);
        hm.put("21111",120);
        hm.put("12222", 120);
        hm.put("11112",120);
        hm.put("22221", 120);
        hm.put("211112",5);
        hm.put("122221", 5);
        
        hm.put("11111",50000);
        hm.put("22222",50000);
        hm.put("211111",50000);
        hm.put("122222",50000);
        hm.put("111112",50000);
        hm.put("222221",50000);
        hm.put("2111112",50000);
        hm.put("1222221",50000);
        
        
	}
	
	//AI�㷨
	public int[] doAI(int AIcolor, int deep) {
		int[][] seatValue = new int[NUM][NUM];
		for(int n=0; n<NUM; n++) {
			for(int m=0; m<NUM; m++) {
				if(seat[m][n] != 0) {	//����Ƿ�������
					continue;
				}
				int num = 0;			//�����Χ2�����Ƿ������ӣ���û���򲻿��Ǹ��������
				for(int i = (n-2>0? n-2:0);i<NUM && i<n+2;i++)
					for(int j= (m-2>0? m-2:0);j<NUM && j<m+2;j++)
						num += seat[i][j];
				if(0==num) {
					continue;
				}
				seat[m][n] = (byte)AIcolor;			//���û�����ӣ���������
				seatValue[m][n] += getValue(m,n);	//��ȡ�������Ӻ�ķ���
				int[] fore = new int[2];
				if(BLACK==AIcolor) {
					if(deep>=0)
						fore = doAI(WHITE, deep-1);
					else 
						fore = doAI(WHITE);
					seat[fore[0]][fore[1]] = (byte)WHITE;
					seatValue[fore[0]][fore[1]] += getValue(fore[0], fore[1]);
					seat[fore[0]][fore[1]] = 0;
					}
				else if(WHITE==AIcolor) {
					if(deep>=0)
						fore = doAI(BLACK, deep-1);
					else 
						fore = doAI(BLACK);
					seat[fore[0]][fore[1]] = (byte)BLACK;
					seatValue[fore[0]][fore[1]] += getValue(fore[0], fore[1]);
					seat[fore[0]][fore[1]] = 0;
				}
				seat[m][n] = 0;
			}
		}
		int Value = 0;
		int X=0,Y=0;
		for(int n=0;n<NUM;n++) {
			for(int m=0;m<NUM;m++) {
				if(Value<seatValue[m][n]) {
					Value = seatValue[m][n];
					X = m;
					Y = n;
				}
			}
		}
//		System.out.println("deep:"+" "+deep+" "+(X+1)+" "+(Y+1));
		int[] bestSeat = {X,Y};
		return bestSeat;
	}
	
	public int[] doAI(int AIcolor) {
		int seatValue[][] = new int[NUM][NUM];
		for(int n=0; n<NUM; n++) {
			for(int m=0; m<NUM; m++) {
				if(seat[m][n] != 0) {	//����Ƿ�������
//					System.out.printf("%6d",seatValue[m][n]);
					continue;
				}
				seat[m][n] = (byte)AIcolor;//���û�����ӣ��������壬������
				seatValue[m][n] = getValue(m, n);
				seat[m][n] = 0;
				}
			}
		int maxValue = 0;
		int X=0,Y=0;
		for(int n=0;n<NUM;n++) {
			for(int m=0;m<NUM;m++) {
				if(maxValue<seatValue[m][n]) {
					maxValue = seatValue[m][n];
					X = m;
					Y = n;
				}
			}
		}
		int[] bestSeat = {X,Y};
		return bestSeat;
	}
	
	
	private int getValue(int x, int y) {
		int value = 0;
		String[] SearchArr = new String[4];
		SearchArr = search(SearchArr, seat, x, y);
		if(SearchArr[0].contains("11111") || SearchArr[0].contains("22222"))
			value += 50000;
		else if(SearchArr[1].contains("11111") || SearchArr[1].contains("22222"))
			value += 50000;
		else if(SearchArr[2].contains("11111") || SearchArr[2].contains("22222"))
			value += 50000;
		else if(SearchArr[3].contains("11111") || SearchArr[3].contains("22222"))
			value += 50000;
		else {
			value += hm.get(SearchArr[0]);
			value += hm.get(SearchArr[1]);
			value += hm.get(SearchArr[2]);
			value += hm.get(SearchArr[3]);
		}
		return value;
	}

}
