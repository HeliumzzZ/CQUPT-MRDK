package course3;

import javax.swing.*;

import java.awt.*;

public class GameUI{

	private GameParam param = new GameParam();
	
	//��Ϸ����
	public void showUI(){
        MyFrame jf = new MyFrame("��������Ϸ");
        jf.setSize(840,720);
        jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        jf.setLocationRelativeTo(null);
        
        //��ť���
        JPanel eastPanel = new JPanel();
        eastPanel.setPreferredSize(new Dimension(160, 20));
        jf.add(eastPanel,BorderLayout.EAST);
        JPanel whitePanel = new JPanel();
        whitePanel.setPreferredSize(new Dimension(200, 60));
        whitePanel.setBackground(new Color(255, 255, 255));
        eastPanel.add(whitePanel,BorderLayout.NORTH);
        JLabel notice = new JLabel("���� \"��ʼ��Ϸ\"");
        notice.setPreferredSize(new Dimension(120, 50));
        whitePanel.add(notice,BorderLayout.CENTER);
        //�������
      	MyPanel board = new MyPanel();
      	board.setPreferredSize(new Dimension(670, 670));
      	board.setBackground(new Color(244,186,106));
      	jf.add(board, BorderLayout.WEST);
      	board.setParam(param);
      	//��ӭ����
      	ImageIcon image = new ImageIcon("������.jpg");
        JLabel welcome = new JLabel(image);
        board.setLayout(new BorderLayout());
        board.add(welcome, BorderLayout.CENTER);
      	
        //��ȡ����
        GameMouse mouse = new GameMouse();
        mouse.setParam(param);
    	mouse.setBoard(board);
    	mouse.setLabel(welcome,notice);
    	//���ܰ�ť
        String name[] = {"��ʼ��Ϸ","���¿�ʼ","����","����","�л�ģʽ","����"};
        for(int i=0;i<name.length;i++){
        	JButton jbu = new JButton(name[i]);
        	jbu.setPreferredSize(new Dimension(90, 33));
        	eastPanel.add(jbu);
        	jbu.addActionListener(mouse);
		}
        
        //�����Ѷ����
        JPanel whiteDif = new JPanel();
        whiteDif.setPreferredSize(new Dimension(160, 100));
        eastPanel.add(whiteDif);
        JPanel setDif = new JPanel();
        setDif.setPreferredSize(new Dimension(160, 200));
        setDif.setBackground(Color.LIGHT_GRAY);
        eastPanel.add(setDif);
        JLabel setDiftext = new JLabel("�˻��Ѷ�����");
        setDif.add(setDiftext, BorderLayout.CENTER);
        String difname[] = {"�ǳ���","��","һ��"};
        for(int i=0;i<difname.length;i++){
        	JButton dif = new JButton(difname[i]);
            dif.setPreferredSize(new Dimension(90, 33));
            setDif.add(dif);
            dif.addActionListener(mouse);
		}
        JButton dif = new JButton("$1 ����");
        dif.setPreferredSize(new Dimension(90, 33));
        setDif.add(dif);
        dif.setEnabled(false);
        JLabel jl = new JLabel("��ʵ����ûд");
        setDif.add(jl);
        
        jf.setVisible(true);
        Graphics g = board.getGraphics();
        mouse.setGraphic(g);
//        jf.setparam(param);
//        jf.setGraphics(g);
        //2.���������������������
        board.addMouseListener(mouse);
        board.addMouseMotionListener(mouse);
    }

    
    public static void main(String[] args) {
        GameUI ui = new GameUI();
        ui.showUI();
    }
}
