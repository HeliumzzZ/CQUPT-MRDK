package course2;

import com.sun.scenario.effect.impl.state.AccessHelper;

import java.util.HashMap;

public class AI implements Config {
    public static HashMap<String, Integer> map = new HashMap<String, Integer>();//设置不同落子情况和相应权值的数组
    private int[][] chessArr;
    private int[][] value = new int[LINE][LINE];
    private int[] position = new int[2];
    private int max;

    public void setChessArr(int[][] chessArr) {
        this.chessArr = chessArr;
    }

    static {
        //被堵住

        map.put("01", 17);//眠1连
        map.put("02", 12);//眠1连
        map.put("001", 17);//眠1连
        map.put("002", 12);//眠1连
        map.put("0001", 17);//眠1连
        map.put("0002", 12);//眠1连

        map.put("0102", 17);//眠1连，15
        map.put("0201", 12);//眠1连，10
        map.put("0012", 15);//眠1连，15
        map.put("0021", 10);//眠1连，10
        map.put("01002", 19);//眠1连，15
        map.put("02001", 14);//眠1连，10
        map.put("00102", 17);//眠1连，15
        map.put("00201", 12);//眠1连，10
        map.put("00012", 15);//眠1连，15
        map.put("00021", 10);//眠1连，10

        map.put("01000", 21);//活1连，15
        map.put("02000", 16);//活1连，10
        map.put("00100", 19);//活1连，15
        map.put("00200", 14);//活1连，10
        map.put("00010", 17);//活1连，15
        map.put("00020", 12);//活1连，10
        map.put("00001", 15);//活1连，15
        map.put("00002", 10);//活1连，10

        //被堵住
        map.put("0101", 65);//眠2连，40
        map.put("0202", 60);//眠2连，30
        map.put("0110", 65);//眠2连，40
        map.put("0220", 60);//眠2连，30
        map.put("011", 65);//眠2连，40
        map.put("022", 60);//眠2连，30
        map.put("0011", 65);//眠2连，40
        map.put("0022", 60);//眠2连，30

        map.put("01012", 65);//眠2连，40
        map.put("02021", 60);//眠2连，30
        map.put("01102", 65);//眠2连，40
        map.put("02201", 60);//眠2连，30
        map.put("00112", 65);//眠2连，40
        map.put("00221", 60);//眠2连，30

        map.put("01010", 75);//活2连，40
        map.put("02020", 70);//活2连，30
        map.put("01100", 75);//活2连，40
        map.put("02200", 70);//活2连，30
        map.put("00110", 75);//活2连，40
        map.put("00220", 70);//活2连，30
        map.put("00011", 75);//活2连，40
        map.put("00022", 70);//活2连，30

        //被堵住
        map.put("0111", 150);//眠3连，100
        map.put("0222", 140);//眠3连，80

        map.put("01112", 150);//眠3连，100
        map.put("02221", 140);//眠3连，80

        map.put("01101", 1000);//活3连，130
        map.put("02202", 800);//活3连，110
        map.put("01011", 1000);//活3连，130
        map.put("02022", 800);//活3连，110
        map.put("01110", 1000);//活3连
        map.put("02220", 800);//活3连

        map.put("01111", 3500);//4连，300
        map.put("02222", 3500);//4连，280
    }

    public int[] setValue() {
        for (int i = 0; i < chessArr.length; i++) {
            for (int j = 0; j < chessArr.length; j++) {
                if (chessArr[i][j] == 0) {
                    String code = "0";
                    //向右
                    int jmax = Math.min(14, j + 4);
                    for (int k = j + 1; k < jmax; k++) {

                        code += chessArr[i][k];

                    }
                    Integer weightright = map.get(code);
                    if (weightright != null) {
                        value[i][j] += weightright;

                    }
                    code = "0";
                    //向左
                    int jmin = Math.max(0, j - 4);
                    for (int k = j - 1; k >= jmin; k--) {

                        code += chessArr[i][k];

                    }
                    Integer weightleft = map.get(code);
                    if (weightleft != null) {
                        value[i][j] += weightleft;

                    }
                    value[i][j] += unionWeight(weightleft, weightright);
                    code = "0";
                    //向下
                    int imax = Math.min(14, i + 4);
                    for (int k = i + 1; k <= imax; k++) {

                        code += chessArr[k][j];

                    }
                    Integer weightdown = map.get(code);
                    if (weightdown != null) {
                        value[i][j] += weightdown;

                    }
                    code = "0";
                    //向上
                    int imin = Math.max(0, i - 4);
                    for (int k = i - 1; k >= imin; k--) {

                        code += chessArr[k][j];

                    }
                    Integer weightup = map.get(code);
                    if (weightup != null) {
                        value[i][j] += weightup;

                    }
                    value[i][j] += unionWeight(weightup, weightdown);
                    code = "0";
                    //右斜向上
                    for (int k = 1; k <= 4; k++) {
                        if ((i - k >= 0) && (i - k <= 14) && (j + k >= 0) && (j + k <= 14)) {
                            code += chessArr[i - k][j + k];
                        }
                    }
                    Integer rightup = map.get(code);
                    if (rightup != null) {
                        value[i][j] += rightup;

                    }
                    code = "0";
                    //左斜向下
                    for (int k = 1; k <= 4; k++) {
                        if ((i + k >= 0) && (i + k <= 14) && (j - k >= 0) && (j - k <= 14)) {
                            code += chessArr[i + k][j - k];
                        }
                    }
                    Integer leftdown = map.get(code);
                    if (leftdown != null) {
                        value[i][j] += leftdown;

                    }



                    value[i][j] += unionWeight(rightup, leftdown);
                    code = "0";
                    //右斜向下
                    for (int k = 1; k < 4; k++) {
                        if ((i + k >= 0) && (i + k <= 14) && (j + k >= 0) && (j + k <= 14)) {
                            code += chessArr[i + k][j + k];
                        }
                    }
                    Integer rightdown = map.get(code);
                    if (rightdown != null) {
                        value[i][j] += rightdown;

                    }
                    code = "0";

                    //左斜向上
                    for (int k = -1; k >= -4; k--) {
                        if ((i + k >= 0) && (i + k <= 14) && (j + k >= 0) && (j + k <= 14)) {
                            code += chessArr[i + k][j + k];
                        }
                    }
                    Integer leftup = map.get(code);
                    if (leftup != null) {
                        value[i][j] += leftup;

                    }
                    value[i][j] += unionWeight(leftup, rightdown);
                    code = "0";

                }

            }

        }

        for (int i = 0; i < value.length; i++) {
            for (int j = 0; j < value.length; j++) {
                if (max < value[i][j]) {
                    position[0] = i;
                    position[1] = j;
                    max = value[i][j];
                }
            }

        }
        return position;
    }

    public Integer unionWeight(Integer a, Integer b) {
        //必须要先判断a,b两个数值是不是null
        if ((a == null) || (b == null)) return 0;
            //一一
        else if ((a >= 10) && (a <= 25) && (b >= 10) && (b <= 25)) return 60;
            //一二、二一
        else if (((a >= 10) && (a <= 25) && (b >= 60) && (b <= 80)) || ((a >= 60) && (a <= 80) && (b >= 10) && (b <= 25)))
            return 800;
            //一三、三一、二二
        else if (((a >= 10) && (a <= 25) && (b >= 140) && (b <= 1000)) || ((a >= 140) && (a <= 1000) && (b >= 10) && (b <= 25)) || ((a >= 60) && (a <= 80) && (b >= 60) && (b <= 80)))
            return 3000;
            //二三、三二
        else if (((a >= 60) && (a <= 80) && (b >= 140) && (b <= 1000)) || ((a >= 140) && (a <= 1000) && (b >= 60) && (b <= 80)))
            return 3000;
        else return 0;
    }


}
