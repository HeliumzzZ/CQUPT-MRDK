package course2;

public class Judgement implements Config {
    private int[][] chessArr;

    public void setChessArr(int[][] chessArr) {
        this.chessArr = chessArr;
    }

    public int judge(int x, int y) {
        int num = 0;
        for (int i = y; i < chessArr.length; i++) {
            if (chessArr[x][y] == chessArr[x][i]) {
                num++;
            } else {
                break;
            }
        }
        for (int i = y - 1; i >= 0; i--) {
            if (chessArr[x][y] == chessArr[x][i]) {
                num++;
            } else {
                break;
            }
        }
        if (num < 5) {
            num = 0;
        }
        for (int i = x; i < chessArr.length; i++) {
            if (chessArr[x][y] == chessArr[i][y]) {
                num++;
                System.out.println(num);
            } else {
                break;
            }
        }
        for (int i = x - 1; i >= 0; i--) {
            if (chessArr[x][y] == chessArr[i][y]) {
                num++;
                System.out.println(num);
            } else {
                break;
            }
        }
        if (num < 5) {
            num = 0;
        }
        for (int i = 0; i < chessArr.length - x && y + i < chessArr.length; i++) {

            if (chessArr[x][y] == chessArr[x + i][y + i]) {
                num++;
            } else {
                break;
            }
        }
        for (int i = 1; x - i >= 0 && y - i >= 0; i++) {

            if (chessArr[x][y] == chessArr[x - i][y - i]) {
                num++;
            } else {
                break;
            }
        }
        if (num < 5) {
            num = 0;
        }
        for (int i = 0; i < chessArr.length - x && y - i >= 0; i++) {

            if (chessArr[x][y] == chessArr[x + i][y - i]) {
                num++;
            } else {
                break;
            }
        }
        for (int i = 1; x-i>=0 && y + i <= chessArr.length; i++) {

            if (chessArr[x][y] == chessArr[x - i][y + i]) {
                num++;
            } else {
                break;
            }
        }
        return num;
    }


}
