package course2;

public interface Config {
    public static final int X0 = 80;
    public static final int Y0 = 80;
    public static final int SIZE = 50;
    public static final int LINE = 15;
    public static final int CHESS = 50;
    public static final int RULE = 5;
}

