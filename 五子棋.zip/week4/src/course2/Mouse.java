package course2;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;

public class Mouse extends MouseAdapter implements Config, ActionListener {
    private int X, Y;
    private boolean count = true;
    private int[][] chessArr = new int[LINE][LINE];
    private Graphics g;
    private String btnText = "123";
    private MyJPanel panel;
    private ArrayList<Chess> chessList = new ArrayList<Chess>();
    private int flag, flag2 = 0;
    private Judgement judgement = new Judgement();
    private int[] position;

    public void setg(Graphics g) {
        this.g = g;
    }

    public int[][] getChessArr() {
        return this.chessArr;
    }

    public void setPanel(MyJPanel panel) {
        this.panel = panel;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        btnText = e.getActionCommand();
        if (btnText.equals("重新开始")) {
            for (int i = 0; i < chessArr.length; i++) {
                for (int j = 0; j < chessArr.length; j++) {
                    chessArr[i][j] = 0;
                }
            }
            flag = 1;
            count = true;
            panel.repaint();
        }
        if (btnText.equals("悔棋")) {
            Chess chess = chessList.get(chessList.size() - 1);
            chessArr[chess.chessX][chess.chessY] = 0;
            count = !chess.count;
            panel.paint(g);
        }
        if (btnText.equals("开始")) {
            flag = 1;
        }
        if (btnText.equals("人机模式")) {
            flag2 = 1;
        }
    }

    public void drawChess(int x, int y) {
        if ((x - X0) % SIZE > SIZE / 2) {
            X = (x - X0) / SIZE + 1;
        } else {
            X = (x - X0) / SIZE;
        }
        if ((y - Y0) % SIZE > SIZE / 2) {
            Y = (y - Y0) / SIZE + 1;
        } else {
            Y = (y - Y0) / SIZE;
        }
        if (count == true && chessArr[X][Y] == 0) {
            g.setColor(Color.black);
            chessArr[X][Y] = 1;
            count = false;
        } else if (count == false && chessArr[X][Y] == 0) {
            g.setColor(Color.white);
            chessArr[X][Y] = 2;
            count = true;
        }
        Chess chess = new Chess(X, Y, count, g.getColor());
        chessList.add(chess);
        g.fillOval(X * SIZE + X0 - CHESS / 2, Y * SIZE + Y0 - CHESS / 2, CHESS, CHESS);
    }

    public void drawChessAi(int x, int y) {
        if ((x - X0) % SIZE > SIZE / 2) {
            X = (x - X0) / SIZE + 1;
        } else {
            X = (x - X0) / SIZE;
        }
        if ((y - Y0) % SIZE > SIZE / 2) {
            Y = (y - Y0) / SIZE + 1;
        } else {
            Y = (y - Y0) / SIZE;
        }
        chessArr[X][Y] = 1;
        Chess chess = new Chess(X, Y, count, g.getColor());
        chessList.add(chess);
        g.fillOval(X * SIZE + X0 - CHESS / 2, Y * SIZE + Y0 - CHESS / 2, CHESS, CHESS);
    }

    public void mouseClicked(MouseEvent e) {
        if (flag == 1 && flag2 != 1) {
            int x = e.getX();
            int y = e.getY();
            drawChess(x, y);

            judgement.setChessArr(chessArr);
            JOptionPane op = new JOptionPane();
            if (judgement.judge(X, Y) >= 5) {
                if (g.getColor() == Color.black) {
                    op.showMessageDialog(null, "黑方胜出");
                } else {
                    op.showMessageDialog(null, "白方胜出");
                }

                flag = 0;
            }
        }
        if (flag == 1 && flag2 == 1) {
            int x = e.getX();
            int y = e.getY();
            AI ai = new AI();
            g.setColor(Color.black);
            drawChessAi(x, y);
            ai.setChessArr(chessArr);
            judgement.setChessArr(chessArr);
            JOptionPane op = new JOptionPane();
            if (judgement.judge(X, Y) >= 5) {
                if (g.getColor() == Color.black) {
                    op.showMessageDialog(null, "黑方胜出");
                } else {
                    op.showMessageDialog(null, "白方胜出");
                }

                flag = 0;

            }
            if (flag != 0) {
                position = ai.setValue();
                chessArr[position[0]][position[1]] = 2;
                panel.paint(g);
                judgement.setChessArr(chessArr);

                if (judgement.judge(position[0], position[1]) >= 5) {
                    if (g.getColor() == Color.black) {
                        op.showMessageDialog(null, "黑方胜出");
                    } else {
                        op.showMessageDialog(null, "白方胜出");
                    }

                    flag = 0;
                }
            }


        }


    }
}
