package course2;

import javax.swing.*;
import java.awt.*;

public class MyJPanel extends JPanel implements Config {
    private int[][] chessArr;

    public void setchessArr(int[][] chessArr) {
        this.chessArr = chessArr;
    }

    public void paint(Graphics g) {
        super.paint(g);
        for (int i = 0; i < LINE; i++) {
            g.drawLine(X0, Y0 + i * SIZE, X0 + (LINE - 1) * SIZE, Y0 + i * SIZE);
            g.drawLine(X0 + i * SIZE, Y0, X0 + i * SIZE, Y0 + (LINE - 1) * SIZE);
        }
        for (int i =0;i<chessArr.length;i++)
        {
            for (int j=0;j<chessArr.length;j++)
            {
                if(chessArr[i][j]==1)
                {
                    g.setColor(Color.black);
                    g.fillOval(i*SIZE+X0-CHESS/2,j*SIZE+Y0-CHESS/2,CHESS,CHESS);
                }
                else if(chessArr[i][j]==2)
                {
                    g.setColor(Color.white);
                    g.fillOval(i*SIZE+X0-CHESS/2,j*SIZE+Y0-CHESS/2,CHESS,CHESS);
                }
            }
        }

    }
}
