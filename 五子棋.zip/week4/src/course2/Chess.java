package course2;

import javax.swing.plaf.IconUIResource;
import java.awt.*;

public class Chess {
    public int chessX,chessY;
    public Color color;
    public boolean count;
    public Chess(int chessX,int chessY,boolean count,Color color)
    {
        this.chessX = chessX;
        this.chessY = chessY;
        this.color = color;
        this.count = count;
    }
}
