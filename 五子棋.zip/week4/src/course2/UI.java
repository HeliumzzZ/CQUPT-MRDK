package course2;

import course1.GameMouse;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.lang.reflect.Array;
import java.util.ArrayList;

public class UI extends JPanel {

    public void showUI(){
        JFrame frame = new JFrame("五子棋");
        frame.setSize(1200,900);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationRelativeTo(null);

        MyJPanel panel = new MyJPanel();
        frame.add(panel, BorderLayout.CENTER);
        JPanel jPanel = new JPanel();
        jPanel.setPreferredSize(new Dimension(250,80));
        jPanel.setLayout(new FlowLayout());
        String[] btname = {"开始","悔棋","重新开始","人机模式"};
        Mouse mouse = new Mouse();
        for(int i=0;i< btname.length;i++)
        {
            JButton bt = new JButton(btname[i]);
            bt.setPreferredSize(new Dimension(200,80));
            bt.addActionListener(mouse);
            jPanel.add(bt);
        }

        frame.add(jPanel,BorderLayout.EAST);
        frame.setVisible(true);

        Graphics g = panel.getGraphics();
        mouse.setg(g);
        mouse.setPanel(panel);
        panel.addMouseListener(mouse);
        panel.setchessArr(mouse.getChessArr());


    }

    public static void main(String[] args) {
        UI ui = new UI();
        ui.repaint();
        ui.showUI();
    }
}
